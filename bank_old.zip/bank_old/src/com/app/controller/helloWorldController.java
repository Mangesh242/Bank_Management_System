package com.app.controller;
import java.sql.*;

import javax.mail.Session;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.aop.aspectj.annotation.PrototypeAspectInstanceFactory;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.util.SystemPropertyUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.app.pojo.user;

import com.app.pojo.User1;

@Controller
public class helloWorldController {
	
	
	@RequestMapping(value = "/demoDatabind", method = RequestMethod.GET)
	public String demoDatabind(Model model) {
		System.out.println("this is demoDatabind controller");
		user u= new user();
		model.addAttribute("User",u);
		return "demoForm";
	}
	
	@RequestMapping(value = "/CheckDemo", method = RequestMethod.POST)
	public String CheckDemo(Model model,@ModelAttribute("User") user user1) {
		System.out.println("this is CheckDemo controller");
		System.out.println("user is "+user1);
		user u= new user();
		model.addAttribute("User", u);
		return "demoForm";
	}
//this is for transaction
	@Transactional
	@RequestMapping(value = "/mstatement", method = RequestMethod.POST)
	public String mstatement(Model model, HttpServletRequest request)throws ClassNotFoundException,SQLException
	{
		int ch=2;//request.getParameter("rollbac");
		System.out.println("*************this is Transaction controller********************");
		System.out.println("want to sent Rs " + request.getParameter("sent"));
		System.out.println(" to account id is  " + request.getParameter("Acc_id"));
	
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Connection con = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/bank", "root", "5326");
		Statement st=con.createStatement();
		
		con.setAutoCommit(false);
		/*if(ch==1)
			{
					con.rollback();
					System.out.println("Performed");
			}
		*/	
		
		/*String q2="insert into transaction where Acc_id= ?";
		PreparedStatement stmt4=con.prepareStatement(q2);
		stmt4.setInt(1,Integer.parseInt(request.getParameter("Acc_id")));
		ResultSet acc=stmt4.executeQuery();
		if(acc.next())
		{
			System.out.println(acc.getString(1));
			System.out.println(acc.getString(2));
			model.addAttribute("Sent_rs", acc.getString(2));
			
		}*/
		
		HttpSession s = request.getSession();
		String acc_id=(String) s.getAttribute("UserAcc_id");
		
		System.out.println(acc_id.length());
		
		if(acc_id==request.getParameter("Acc_id"))
		{  
			System.out.println("Sry Enter Another user's Acc Id not yours");
			model.addAttribute("Sent_Successfully", "Sry Enter Another user's Acc Id not yours");
			return "moneytransfer";
		}
			
		System.out.println("we are checking balance of acc id"+acc_id);
		String query="select balance from person where Acc_id=?";
		PreparedStatement stmt=con.prepareStatement(query);
		stmt.setString(1,acc_id);
		ResultSet rs=stmt.executeQuery();
		if(rs.next())
		{
			/*System.out.println("account number of sender is "+acc_id);
			String scheck_Balance="SELECT balance FROM person WHERE Acc_id=?";
			PreparedStatement stmt3=con.prepareStatement(scheck_Balance);
			stmt3.setInt(1,Integer.parseInt(acc_id));
			
			ResultSet rs2=stmt3.executeQuery();*/
			
			int balance=rs.getInt(1);
			System.out.println("current balance of the account"+acc_id+" is "+balance);
			if(balance>Integer.parseInt(request.getParameter("sent")))
			{
			
					String transfer="update person set balance=balance+? where Acc_id=?";
					PreparedStatement stmt2=con.prepareStatement(transfer);
					stmt2.setInt(1,Integer.parseInt(request.getParameter("sent")));
					stmt2.setString(2,request.getParameter("Acc_id"));
					
					int rs2=stmt2.executeUpdate();
					System.out.println(rs2);
					if(rs2>0)
					{

						String deduct="update person set balance=balance-? where Acc_id=?";
						PreparedStatement stmt4=con.prepareStatement(deduct);
						stmt4.setInt(1,Integer.parseInt(request.getParameter("sent")));
						stmt4.setString(2,acc_id);					
						int rs3=stmt4.executeUpdate();
						System.out.println("rs3 is "+rs3);						
						if(rs3>0) {
						
						System.out.println("updated successfully");
						model.addAttribute("Sent_Successfully", "Money Sent Successfully");
						model.addAttribute("Sent_Rs","sent rs is :"+request.getParameter("sent"));
						con.commit();
						}
						else {
							System.out.println("money is sent but not deduct from the account");
							con.rollback();
						}
						
					}
					else {
						System.out.println("valid user but some error ");
						
					}	
			}
			else {
				System.out.println("this user do not have sufficient balance to send the ammout of: "+request.getParameter("sent"));
				System.out.println("current balance of the account is "+balance);
				model.addAttribute("Sent_Successfully", "This user do not have sufficient balance");
			}
		}else
		{
			System.out.println("no such user found with name ");
		}
			
		
		return "moneytransfer";
	  	
	}
	//this controller is for mini statement
	@RequestMapping(value = "/miniStatement", method = RequestMethod.POST)
	public String miniStatement(Model model, HttpServletRequest request)throws ClassNotFoundException,SQLException
	{
		
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Connection con = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/bank", "root", "5326");
		Statement st=con.createStatement();
		   String query_transaction="select *from transaction";
		   ResultSet set =st.executeQuery(query_transaction);
		   while(set.next())
		   {
			   System.out.println(set.getString(2));
			   model.addAttribute("first",set.getString(2));
				

			   
			   
		   }
	  return "ministatement";
	}

//home work This is signup Controller
	@RequestMapping(value = "/demoDatabind1", method = RequestMethod.GET)
	public String demoDatabind1(Model model) {
		System.out.println("this is sign up controller it jumped to the signup page");
		User1 u= new User1();
		model.addAttribute("User12",u);
		return "index2";
	}
	
	@RequestMapping(value = "/CheckDemo1", method = RequestMethod.POST)
	public String CheckDemo1(Model model,@ModelAttribute("User12") User1 user2)throws ClassNotFoundException,SQLException {
		System.out.println("this is demoDatabind controller");
		System.out.println("user name is "+user2);
		
	// we got connection over here 
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Connection con = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/bank", "root", "5326");
		Statement st=con.createStatement();
		 //if we want then create a table then : String q1="create table signup2(eid int)";
         String q1="insert into person (username, password, gender, email_id, full_name, Address) values('"+user2.getUsername()+"','"+user2.getPassword()+"','"+user2.getGender()+"','"+user2.getEmail_id()+"','"+user2.getFull_name()+"','"+user2.getAddress()+"')";
        
         String q5="select *from person";
         st.executeUpdate(q1);
        
         ResultSet set =st.executeQuery(q5);
         while(set.next())
         {
        	 	
        	 
        	  System.out.println(set.getString(1));
        	  System.out.println(set.getString(2));
        	  System.out.println(set.getString(3));

        	  System.out.println(set.getString(4));
        	  System.out.println(set.getString(5));
        	  System.out.println(set.getString(9));
        	  
         }
     //data uploaded to database
		return "index2";
	}
	


	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public String ExistingInstitutes(Model model) {
		System.out
				.println("this is hello world controller and msg is sent to medel");
		model.addAttribute("message", "this data is from controller");
		return "helloworld";
	}
	
	//login controller

	@RequestMapping(value = "/CheckLogin", method = RequestMethod.POST)
	public String CheckLogin(Model model, HttpServletRequest request) {
		System.out.println("this is CheckLogin controller");
		System.out.println("username is " + request.getParameter("username"));
		System.out.println("password is " + request.getParameter("password"));
		
		String output="";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			java.sql.Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/bank", "root", "5326");
	
		// here bank is database name, root is username and 5326 is password
			
			Statement stmt = con.createStatement();
			//String query="select * from login where username='"+request.getParameter("username")+"' and password='"+request.getParameter("password")+"'";
			String query1="select * from person where username='"+request.getParameter("username")+"' and password='"+request.getParameter("password")+"'";
			
			
			  
			  ResultSet rs = stmt.executeQuery(query1);
			if (rs.next())
			{

				
				HttpSession s = request.getSession();
				
				//User1 u=new User1(rs.getString("username"),rs.getString("password"),(String)rs.getString("Address"),(String)rs.getString("email_id"),(String)rs.getString("Acc_id"),(String)rs.getString("balance"),(String)rs.getString("gender"));
				s.setAttribute("username",rs.getString("username"));
				s.setAttribute("password",rs.getString("password"));
			    s.setAttribute("Address",(String)rs.getString("Address"));
			    s.setAttribute("email_id",(String)rs.getString("email_id"));
			    s.setAttribute("UserAcc_id",(String)rs.getString("Acc_id"));
			    s.setAttribute("balance",(String)rs.getString("balance"));
			    s.setAttribute("gender",(String)rs.getString("gender"));
			    
				System.out.println(rs.getString(1) + "  " + rs.getString(2) + "  "
						+ rs.getString(3));
				
				//this are for transaction table 
				
				System.out.println("login successfull");
				output="loginSuccess";
			}			
			else
			{
				System.out.println("yes result set is empty");
				output="index2";
				model.addAttribute("errorMessage", "Username or Password is not Correct please try again");
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

		return output;
	}

	@RequestMapping(value = "/deleteaccountcontroller", method = RequestMethod.POST)
	public String deleteaccountcontroller(Model model, HttpServletRequest request)throws ClassNotFoundException,SQLException
	{
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Connection con = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/bank", "root", "5326");
		Statement st12=con.createStatement();
		
		System.out.println("Username is going to delete:" + request.getParameter("username"));
		
		String query_delete="delete from person where username ='"+request.getParameter("username")+"' ";
		
		int x=st12.executeUpdate(query_delete);
		System.out.println(x);
		if(x>0)
		{
		
			System.out.println("deleted successfully");
		    model.addAttribute("deleteaccountmessage", "Your account deleted successfully");
		
		}
		else
		{
			model.addAttribute("error_in_username","Username is not exist.Please enter your valid username");
			return "loginSuccess";
			
		}
		return "index2";
	}
	//this is to edit profile of user  still checking of old username is remaining
	
	@RequestMapping(value = "/editcontroller", method = RequestMethod.POST)
	public String editcontroller(Model model, HttpServletRequest request)throws ClassNotFoundException,SQLException
	{
		HttpSession s = request.getSession();
		
		int ch=Integer.parseInt(request.getParameter("choice"));
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Connection con = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/bank", "root", "5326");
				
		 switch(ch)
		 { 
		 case 1:
			 if(s.getAttribute("username")==request.getParameter("username1"))
			 {
				 System.out.println("Correct old username");
			 }
			 else
			 {
				 model.addAttribute("error_in_username","Enter correct old username");
			 }
			 String userquery="update person set username=? where password=?";
			 PreparedStatement state_edit=con.prepareStatement(userquery);
			 state_edit.setString(1,request.getParameter("username1")); //this is new username
			 state_edit.setString(2,(String) s.getAttribute("password"));  //password we are getting from session id
			
			
				System.out.println(request.getParameter("username1"));
				System.out.println(request.getParameter("username"));
				int rs2=state_edit.executeUpdate();
				if(rs2==1)
				{
					System.out.println("updated successfully");
					s.setAttribute("username",request.getParameter("username1"));
					//to set updated value to session variables
				}
				else
				{
					model.addAttribute("error_in_username","Enter correct old username");
					return "editprofile";
				}
			 
			  System.out.println("Choice is one ");
			  
			  break;
		 case 2:
			 String passquery="update person set password=? where username=?";
			 PreparedStatement statepass_edit=con.prepareStatement(passquery);
			 statepass_edit.setString(1,request.getParameter("password"));
			 statepass_edit.setString(2,(String) s.getAttribute("username"));
			
			 int rs3=statepass_edit.executeUpdate();
				if(rs3==1)
				{
					System.out.println("updated successfully");
				
				}
				else
				{
					model.addAttribute("error_in_username","Enter correct old password");
					return "editprofile";
				}
			 
			 

			  System.out.println("Choice is two ");
			  break;
			  
		 case 3:
			 String fullnamequery="update person set full_name=? where username=?";
			 PreparedStatement statefullname_edit=con.prepareStatement(fullnamequery);
			 statefullname_edit.setString(1,request.getParameter("full_name"));
			 statefullname_edit.setString(2,(String) s.getAttribute("username"));
				
				int rs4=statefullname_edit.executeUpdate();
				if(rs4==1)
				{
					System.out.println("updated successfully");
				
				}
				else
				{
					model.addAttribute("error_in_username","Enter correct old full_name");
					return "editprofile";
				}
			 
			 

			  System.out.println("Choice is three ");
			  break;
		 case 4:
			 String emailquery="update person set email_id=? where username=?";
			 PreparedStatement stateemail_edit=con.prepareStatement(emailquery);
			 stateemail_edit.setString(1,request.getParameter("email_id"));
			 stateemail_edit.setString(2,(String) s.getAttribute("username"));
				
			 int rs5=stateemail_edit.executeUpdate();
				if(rs5==1)
				{
					System.out.println("updated successfully");
				
				}
				else
				{
					model.addAttribute("error_in_username","Enter correct old Email Id");
					return "editprofile";
				}
			 
			 

			  System.out.println("Choice is three ");
			  break;
		 case 5:
			 String addquery="update person set Address=? where username=?";
			 PreparedStatement stateaddress_edit=con.prepareStatement(addquery);
			 stateaddress_edit.setString(1,request.getParameter("Address"));
			 stateaddress_edit.setString(2,(String) s.getAttribute("username"));
				
			 int rs6=stateaddress_edit.executeUpdate();
				if(rs6==1)
				{
					System.out.println("updated successfully");
				
				}
				else
				{
					model.addAttribute("error_in_username","Enter correct old Address");
					return "editprofile";
				}
			 
			 

			  System.out.println("Choice is three ");
			
			 	
		 }
		return "loginSuccess";
	}
	@RequestMapping(value = "/logout", method = RequestMethod.POST)
	public String logout(Model model, HttpServletRequest request)throws ClassNotFoundException,SQLException
	{
		HttpSession s = request.getSession();
		s.removeAttribute("username");
		s.removeAttribute("password");
		s.removeAttribute("Address");
		/*s.removeAttribute("Address");
		s.removeAttribute("Address");
		s.removeAttribute("Address");*/
		
		
		System.out.println(s.getAttribute("username"));
		System.out.println(s.getAttribute("password"));
		System.out.println(s.getAttribute("Address"));
	
      return "index";
	}
}
	

