package com.app.pojo;

public class User1{
	String username;
	String password;
	String gender;

	String email_id;
	String full_name;
	String Address;
	
	public User1(String username, String password, String gender, String email_id, String full_name, String address) {
		super();
		this.username = username;
		this.password = password;
		this.gender = gender;
		this.email_id = email_id;
		this.full_name = full_name;
		Address = address;
	}
	public User1() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public String getFull_name() {
		return full_name;
	}
	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	@Override
	public String toString() {
		return "User1 [username=" + username + ", password=" + password + ", gender=" + gender + ", email_id="
				+ email_id + ", full_name=" + full_name + ", Address=" + Address + "]";
	}
	
	

}
