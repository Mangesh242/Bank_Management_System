package com.app.pojo;



public class user {
	String name;
	String password;
	public user(String name, String password) {
		super();
		this.name = name;
		this.password = password;
	}
	public user() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "user [name=" + name + ", password=" + password + "]";
	}
	

}
